  In the SETDEF.py file, you can change the default
directory of the CMD