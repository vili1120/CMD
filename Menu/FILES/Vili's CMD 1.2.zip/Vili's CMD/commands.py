import random
import os
import CALC
import time

LINE = '---------------------------------------------------------------'

MONEY = int(10)

SWORDSTOCK = int(1)

def Print():
  PRINT = input('print> ')
  
  Cls()
  print("Made by Vili1120")
  print("For help just type help.")
  
  print(PRINT)
  print(LINE)
  
def Help():
  print("help - This command shows the list of the commands.")
  print(LINE)
  print("print - With this command you can print anything you want.")
  print(LINE)
  print("println - You can print multiple lines.")
  print(LINE)
  print("setp - With this you can set up a profile.")
  print(LINE)
  print("pinfo - This shows the information about your profile.")
  print(LINE)
  print("picture - With this you can see a picture(tree, house)")
  print(LINE)
  print("games - With this command you can play games.")
  print(LINE)
  print("store - You can buy things.")
  print(LINE)
  print("money - This shows how much money you have.")
  print(LINE)
  print("roll - You can generate a random number between 1 and 6.")
  print(LINE)
  print("cls - clears the screen.")
  print(LINE)
  print("calc - You can calculate anything you want.(Operators: +, -, *, /)")
  print(LINE)
  print("troll - ¨¨\(°_°)/¨¨")
  print(LINE)
  print("setdef - changes the default directory.")
  print(LINE)
  print("shutdown - shuts down the CMD.")
  print(LINE)
  
def PrintLn():
  print("you can print up to 5 lines.")
  LINE1 = input('line 1> ')
  LINE2 = input('line 2> ')
  LINE3 = input('line 3> ')
  LINE4 = input('line 4> ')
  LINE5 = input('line 5> ')
  
  Cls()
  print("Made by Vili1120")
  print("For help just type help.")
  
  print(LINE1)
  print(LINE2)
  print(LINE3)
  print(LINE4)
  print(LINE5)
  
  print(LINE)
  
def Info():
  print("Version: 1.2")
  print("I don't know why i made this.")
  print("Started on 2023.11.18")
  print("date: year.month.day")
  print("First version done on 2023.11.19")
  
def Picture():
  PICTURE = input('picture> ')
  
  if PICTURE == 'house':
    print('                         ||||')
    time.sleep(0.5)
    print('                       ||||||||')
    time.sleep(0.5)
    print('                     ||||||||||||')
    time.sleep(0.5)
    print('                   ||||||||||||||||')
    time.sleep(0.5)
    print('                     ||||||||||||')
    time.sleep(0.5)
    print('                     |||||  |||||')
    time.sleep(0.5)
    print('                     |||||  |||||')
    time.sleep(0.5)
    print(LINE)
    
  if PICTURE == 'tree':
    print('                     |||||||||||||||')
    time.sleep(0.5)
    print('                   |||||||||||||||||||')
    time.sleep(0.5)
    print('                 |||||||||||||||||||||||')
    time.sleep(0.5)
    print('                 |||||||||||||||||||||||')
    time.sleep(0.5)
    print('                   |||||||||||||||||||')
    time.sleep(0.5)
    print('                        ||||||||')
    time.sleep(0.5)
    print('                        ||||||||')
    time.sleep(0.5)
    print('                        ||||||||')
    time.sleep(0.5)
    print('                        |||  |||')
    time.sleep(0.5)
    print('                        ||||||||')
    time.sleep(0.5)
    print('                        ||||||||')
    time.sleep(0.5)
    print('                       ||||||||||')
    time.sleep(0.5)
    print('                      ||||||||||||')
    time.sleep(0.5)
    print(LINE)
    
def Asd():
  print("You've just found an easter egg!")
  print("That shuts down the CMD!")
  print("Or not?")
  
def Games():
  global SWORDSTOCK
  global MONEY
  print("Games: - Math Game")
  print("       - Asd")
  print(LINE)
  GAME = input('game> ')
  
  if GAME == 'Math Game':
    print("What's 1+1?")
    Answer1 = input('1+1=')
    
    if Answer1 == '2':
      time.sleep(0.8)
      print("Ok, good.")
      time.sleep(0.8)
      print("What's 2+2?")
      Answer2 = input('2+2=')
      
      if Answer2 == '4':
        time.sleep(0.8)
        print("What's 4+4?")
        Answer3 = input('4+4=')
        
        if Answer3 == '8':
          time.sleep(0.8)
          print("Okay, you've completed the game.")
          MONEY += 10
          
        else:
          print("Bruh")
          
      else:
        print("WHAT THE HELL?!?!?!??!")
        
    else:
      print("What in the duck are you thinking?!!?!?!")
      
  if GAME == 'Asd':
    print("What's your name?")
    NAME = input('My name is ')
    
    print("Hello " + NAME + " !")
    
    print("What is your credit card number?")
    CREDITCARD = input('My credit card number is ')
    
    print("Ok, thanks.")
    MONEY -= 5
    SWORDSTOCK += 1
    
def Store():
  global MONEY
  global SWORDSTOCK
  print("Hello, welcome to my store!")
  print("Do you want to buy anything?")
  print("Type Yes or No")
  ANSWER = input('Answer> ')
  
  if ANSWER == 'Yes':
    print("What do you want to buy?")
    print(LINE)
    print("sword - 10$ stock: " + str(SWORDSTOCK))
    print(LINE)
    
    BUY = input('Buy> ')
    
    if BUY == 'sword' and MONEY >= 10 and SWORDSTOCK >= 1:
      print("Okay here you go.")
      MONEY -= 5
      SWORDSTOCK -= 1
      
    elif MONEY < 10:
      print("Sorry, but you don't have enough money.")
      print("To earn money play games.")
      
    elif SWORDSTOCK < 1:
      print("Sorry we are out of stock.")
      print("Play (Asd) game to get us stock")
      
def Money():
  print("you have " + str(MONEY) + " dollars.")
  
def Roll():
  ROLL = random.randint(1, 6)
  print("Okay I'm rolling the dice.")
  time.sleep(1)
  print("The number is " + str(ROLL))
  
def Cls():
  os.system('cls')
  
def Calc():
  Operator = input('Operator> ')
  OPERATORS = ['+','-','*','/']
  
  if Operator == '+':
    CALC.Plus()
    
  if Operator == '-':
    CALC.Minus()
    
  if Operator == '*':
    CALC.Times()
    
  if Operator == '/':
    CALC.Divide()
    
  if Operator not in OPERATORS:
    print("please enter a valid operator")
    
def Troll():
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)
  print('AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA')
  time.sleep(0.2)