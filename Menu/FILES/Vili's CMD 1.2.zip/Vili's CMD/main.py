import commands
import SETDEF
import os
import time

os.system('cls')

print("Made by Vili1120")
print("For help just type help.")

run = True

CD = 'CMD'

DEF = SETDEF.SETDEF

PSET = False

while run == True:

  COMMAND = input(f'{CD}> ')
  
  if COMMAND == 'print':
    commands.Print()
    
  if COMMAND == 'help':
    commands.Help()
    
  if COMMAND == 'println':
    commands.PrintLn()
    
  if COMMAND == 'shutdown':
    print("The CMD is shutting down in:")
    time.sleep(0.5)
    print('3')
    time.sleep(0.5)
    print('2')
    time.sleep(0.5)
    print('1')
    time.sleep(0.5)
    run = False
    
  if COMMAND == 'setp':
    USERNAME = input('Username: ')
    PASSWORD = input('Password: ')
    print(commands.LINE)
    PSET = True
    CD = USERNAME
    
  if COMMAND == 'pinfo' and PSET == True:
    print("Username: " + USERNAME)
    print("Password: " + PASSWORD)
    print(commands.LINE)
    
  elif PSET == False and COMMAND == 'pinfo':
    print("Please set up a profile first!")
    
  if COMMAND == 'info':
    commands.Info()
    
  if COMMAND[:2] == 'cd':
    CD = COMMAND[3:]
    if CD == 'USER' and PSET == True:
      CD = USERNAME
    elif CD == 'USER' and PSET == False:
      CD = 'CMD'
      print("You don't have a profile yet!")
    elif CD == 'ABC(EN)':
      CD = 'ABCDEFGHIJKLMONPQRSTUVWXYZ'
    elif CD == 'ABC(HU)':
      CD = 'AÁBCCSDDZDZSEÉFGGYHIÍJKLLYMNNYOÓÖŐPQRSSZTTYUÚÜŰVWXYZZS'
    elif CD == 'DEF':
      CD = DEF
    
  if COMMAND == 'picture':
    commands.Picture()
    
  if COMMAND == 'asd':
    commands.Asd()
    
  if COMMAND == 'games':
    commands.Games()
    
  if COMMAND == 'store':
    commands.Store()
    
  if COMMAND == 'money':
    commands.Money()
    
  if COMMAND == 'roll':
    commands.Roll()
    
  if COMMAND == 'cls':
    commands.Cls()
    print("Made by Vili1120")
    print("For help just type help.")
    
  if COMMAND == 'calc':
    commands.Calc()
    
  if COMMAND[:6] == 'setdef':
    DEF = COMMAND[7:]
    
  if COMMAND == 'troll':
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()
    commands.Troll()