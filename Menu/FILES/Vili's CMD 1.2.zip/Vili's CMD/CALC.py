NUMBER1 = int(0)
NUMBER2 = int(0)
EQUAL = int(0)

NUMBERS = '0123456789'

def Plus():
  global NUMBER1
  global NUMBER2
  global EQUAL
  
  NUMBER1 = input('1st number> ')
  
  NUMBER2 = input('2nd number> ')
    
  EQUAL = int(NUMBER1) + int(NUMBER2)
  print(str(EQUAL))
  
def Minus():
  global NUMBER1
  global NUMBER2
  global EQUAL
  
  NUMBER1 = input('1st number> ')
  
  NUMBER2 = input('2nd number> ')
  
  EQUAL = int(NUMBER1) - int(NUMBER2)
  print(str(EQUAL))
  
def Divide():
  global NUMBER1
  global NUMBER2
  global EQUAL
  
  NUMBER1 = input('1st number> ')
  
  NUMBER2 = input('2nd number> ')
    
  EQUAL = int(NUMBER1) / int(NUMBER2)
  print(str(EQUAL))
  
def Times():
  global NUMBER1
  global NUMBER2
  global EQUAL
  
  NUMBER1 = input('1st number> ')
  
  NUMBER2 = input('2nd number> ')
    
  EQUAL = int(NUMBER1) * int(NUMBER2)
  print(str(EQUAL))