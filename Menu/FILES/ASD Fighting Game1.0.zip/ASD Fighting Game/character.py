from weapon import *
from healthbar import HealthBar

class Character:
    def __init__(self, race: str, name: str, health: int, heal_power: int) -> None:
        self.race = race
        self.name = name
        self.health = health
        self.health_max = health
        self.heal_power = heal_power
        
        self.weapon = iron_sword
        
    def attack(self, target) -> None:
        target.health -= self.weapon.damage
        target.health = max(target.health, 0)
        target.health_bar.update()
        print(f"{self.race} {self.name} dealt {self.weapon.damage} to {target.race} {target.name} with {self.weapon.name}")
        
    def heal(self, heal_power):
        self.health += self.heal_power
    
class Hero(Character):
    def __init__(self, race: str, name: str, health: int, weapon, heal_power: int) -> None:
        super().__init__(race=race, name=name, health=health, heal_power=heal_power)
        
        self.weapon = weapon
        self.health_bar = HealthBar(self, color="green")
        
class Enemy(Character):
    def __init__(self, race: str, name: str, health: int, weapon, heal_power: int) -> None:
        super().__init__(race=race, name=name, health=health, heal_power=heal_power)
        
        self.weapon = weapon
        self.health_bar = HealthBar(self, color="red")