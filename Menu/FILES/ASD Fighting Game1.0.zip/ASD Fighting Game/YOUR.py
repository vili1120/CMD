from weapon import *

YOURWEAPON = Weapon(name="your weapon",
                    weapon_type="your weapon type",
                    damage=5,
                    value=10)

YOUR = ["YourChar", 100, YOURWEAPON, YOURWEAPON.damage]