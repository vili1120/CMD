from character import Hero, Enemy
from weapon import *
from YOUR import *
import os
import random
import time

def CLS():
    os.system('cls')

mage = ["Mage", 125, Magic_wand, 6] #[name, health, weapon, healing power]
warrior = ["Warrior", 100, iron_sword, 5] #[name, health, weapon, healing power]
rogue = ["Rogue", 80, knife, 4] #[name, health, weapon, healing power]

TYPE = None
E_TYPE = None

E_CHOOSE = random.randint(1, 3)
    
if E_CHOOSE == 1:
    E_TYPE = mage
elif E_CHOOSE == 2:
    E_TYPE = warrior
elif E_CHOOSE == 3:
    E_TYPE = rogue
    
CLS()

print(f"""
Choose your heroes type:
    -{mage[0]}[Hp: {mage[1]}, Weapon: {mage[2].name}, Healing: {mage[3]}]: 1
    -{warrior[0]}[Hp: {warrior[1]}, Weapon: {warrior[2].name}, Healing: {warrior[3]}]: 2
    -{rogue[0]}[Hp: {rogue[1]}, Weapon: {rogue[2].name}, Healing: {rogue[3]}]: 3
    -{YOUR[0]}[Hp: {YOUR[1]}, Weapon: {YOUR[2].name}, Healing: {YOUR[3]}]: 4
""")

CHOOSE = input("Hero Type: ")

if CHOOSE == "1":
    TYPE = mage
elif CHOOSE == "2":
    TYPE = warrior
elif CHOOSE == "3":
    TYPE = rogue
elif CHOOSE == "4":
    TYPE = YOUR

CLS()

hero = Hero(race='Human', name=TYPE[0], health=TYPE[1], weapon=TYPE[2], heal_power=TYPE[3])
enemy = Enemy(race='Goblin', name=E_TYPE[0], health=E_TYPE[1], weapon=E_TYPE[2], heal_power=E_TYPE[3])

while True:
    hero.health_bar.draw()
    enemy.health_bar.draw()
    DO = input('Fight(f)|Heal(h)|Run(r)')
    if DO == "f":
        hero.attack(enemy)
    elif DO == "h":
        hero.heal(hero.heal_power)
    elif DO == "r":
        CLS()
        exit()
    E_DO = random.randint(1, 6)
    if E_DO == 3:
        enemy.heal(enemy.heal_power)
    else:
        enemy.attack(hero)
    
    CLS()
    
    hero.health_bar.draw()
    enemy.health_bar.draw()
    CLS()
    
    if hero.health == 0:
        CLS()
        print(f"You lost this battle against {enemy.race} {enemy.name}!")
        time.sleep(1)
        exit()
    if enemy.health == 0:
        CLS()
        print(f"You've won this battle against {enemy.race} {enemy.name}!")
        time.sleep(1)
        exit()