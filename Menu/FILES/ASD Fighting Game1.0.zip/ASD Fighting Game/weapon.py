class Weapon:
    def __init__(self, name: str,
                weapon_type: str,
                damage: int,
                value: int) -> None:
        self.name = name
        self.weapon_type = weapon_type
        self.damage = damage
        self.value = value
        
iron_sword = Weapon(name="Iron Sword",
                    weapon_type="sharp",
                    damage=5,
                    value=10)
                    
Magic_wand = Weapon(name="Magic Wand",
                    weapon_type="magic",
                    damage=4,
                    value=8)
                    
knife = Weapon(name="Knife",
               weapon_type="very sharp",
               damage=6,
               value=12)